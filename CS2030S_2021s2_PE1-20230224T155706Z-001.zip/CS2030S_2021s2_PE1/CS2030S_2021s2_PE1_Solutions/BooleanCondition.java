/**
 * CS2030S PE1 Question 2
 * AY20/21 Semester 2
 *
 * @author Boyd Anderson
 */
interface BooleanCondition<T> {
  boolean test(T t); 
}
