## **- checkstyle_errors -0 --**

Your code contains a few violations of CS2030S Java style guide, as reported by \texttt{checkstyle}. No deduction is made for PE1, but please make sure that \texttt{checkstyle} does not report any error next time.

## **- checkstyle_errors -1 --**

Your code violates the CS2030S Java style guide many times, as reported by \texttt{checkstyle}.

## **- checkstyle_errors -2 --**

Your code violates the CS2030S Java style guide many many times, as reported by \texttt{checkstyle}.

## **- const_should_be_final_static -0 --**

You have extracted out constants as a field, which is good. But, remember that constants should be declared as both \texttt{static} and \texttt{final}! No mark deduction for PE1, but next time, we may deduct some marks.

## **- correctness -2 --**

Test2 failed to run. This is most likely due to compilation error.

## **- correctness -3 --**

Both Test1 and Test2 failed to run, most likely due to compilation error.

## **- expression_not_abstract -1 --**

It is good that you have \texttt{Expression} as a common superclass for both \texttt{Operand} and \texttt{Operation}. However, \texttt{Expression} should be abstract. It cannot be evaluated without knowing what type of expression it is.

## **- fields_not_private -1 --**

You have declared some fields using default access modifier (i.e., package private). This violates the information hiding principle. You should keep all fields as \texttt{private}. If you have only one class with package-private fields, we let it go without penalty. This deduction applies only if you have more than one class with package-private fields.

## **- ioe_does_not_extend_runtimeexception -1 --**

The \texttt{InvalidOperandException} should be an unchecked exception and inherits from \texttt{RuntimeException}.

## **- no_exception_handling -1 --**

Your code does not throw \texttt{InvalidOperandException} properly (either not throwing it at all or not throwing it correctly).

## **- no_instance_of -1 --**

We expect that your design includes a way to check if the operands are valid during run-time. This can be done using \texttt{instanceof} operator. We cannot identify places in your code where you do this.

## **- not_checking_valid_operand_properly -1 --**

Your code should include a way to check that the operands are of the right type during run-time. This should be done using conditional statements (checking the type using \texttt{instanceof}). Many of you use catches other run-time exception (e.g., \texttt{ClassCastException}) to handle this logic. Such approach is neither robust nor efficient and should be avoided.

## **- not_extending_from_operation -1 --**

You have created classes to implement individual operations. These classes should inherit from \texttt{Operation}.

## **- not_modeling_operations_as_subclasses -1 --**

The operations xor, multiplication, and concatenation should be implemented in its own subclasses. Such design allows us to extend the code with other operations more easily. We deduct one point for each missing subclass of \texttt{Operation}.

## **- not_modeling_operations_as_subclasses -2 --**

The operations xor, multiplication, and concatenation should be implemented in its own subclasses. Such design allows us to extend the code with other operations more easily. We deduct one point for each missing subclass of \texttt{Operation}.

## **- not_modeling_operations_as_subclasses -3 --**

The operations xor, multiplication, and concatenation should be implemented in its own subclasses. Such design allows us to extend the code with other operations more easily. We deduct one point for each missing subclass of \texttt{Operation}.

## **- of_not_static -1 --**

The \texttt{of} method from the class \texttt{Operation} should be a class method and declared with the \texttt{static} keyword.

## **- operand_operation_not_related -3 --**

The two classes \texttt{Operand} and \texttt{Operation} should be related to each other in someway, so that the \texttt{Operation} can recursively operates on other operations. This can be done either through creating a common supertype for both (e.g., \texttt{Expression} or \texttt{Evaluatable}) or make \texttt{Operand} a subclass of \texttt{Operation}.

## **- operation_not_abstract -1 --**

The class \texttt{Operation} should be abstract (per requirement of the question).

## **- protected_is_not_private -1 --**

You have declared some fields using the \texttt{protected} access modifier (i.e., package public). This violates the information hiding principle. You should keep all fields as \texttt{private}. All methods to be used by the client should be \texttt{public}.

## **- test1-incorrect -1 --**

Test1 compiles and runs, but some of the test cases have failed.

## **- test2-failed -2 --**

Test2 failed to run. This is most likely due to compilation error.

## **- test2-incorrect -1 --**

Test2 compiles and runs, but some of the test cases have failed.